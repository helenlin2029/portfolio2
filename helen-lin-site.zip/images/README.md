Put your photos in this folder.

Use lowercase filenames with no spaces, e.g. `hangar-2023.jpg`, and resize to about
1600px on the long edge so the page stays fast.

Then in `index.html`, replace a photo box:

    <div class="frame">Photo slot — ...</div>

with your image, keeping the same class:

    <img class="frame" src="images/hangar-2023.jpg" alt="Short description">
